<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	function __construct(){
		parent::__construct();
		//load chart_model dari model
		$this->load->model('M_chart');
	}
	public function index()
	{
		check_not_login();
		$data = $this->M_chart->get_data()->result();
		$x['data'] = json_encode($data);
		$this->template->load('template','dashboard',$x);
	}

}