<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {
  function __construct(){
    parent::__construct();
    check_not_login();
    $this->load->model('M_sales');
    $this->load->model('M_item');
  }

  public function Rsales()
  {
    $data['ref'] = $this->M_sales->get_ref()->result();
    $data['row'] = $this->M_sales->get_sales();
    $this->template->load('template','report/sale_report',$data);
  }

  public function sale_product($id_sale = null)
  {
      $detail = $this->M_sales->get_sales_detail($id_sale)->result();
      echo json_encode($detail);
  }

  public function export_excel($id_sale = null)
  {
    $data['sales'] = $this->M_sales->get_sales($id_sale)->result();
    $data['detail'] = $this->M_sales->get_sales_detail($id_sale)->result();
    $this->template->load('template','export_excel',$data);
  }
  
  public function export($id_sale = null){
    // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    
    // Panggil class PHPExcel nya
    $excel = new PHPExcel();
    // Settingan awal fil excel
    $excel->getProperties()->setCreator('My Notes Code')
                 ->setLastModifiedBy('My Notes Code')
                 ->setTitle("Debit Note")
                 ->setSubject("Debit Note")
                 ->setDescription("Laporan Debit Note")
                 ->setKeywords("Debit Note");
    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel

    $styleArray = array(
      'font'  => array(
           'name'  => 'Arial'
       ));      
    $phpColor = new PHPExcel_Style_Color();
    $phpColor->setRGB('757171');

    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      )
      
      // 'borders' => array(
      //   'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
      //   'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
      //   'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
      //   'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      // )
    );
    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $style_row = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Menambahkan file gambar pada document excel pada kolom B2
    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Media Kreatif Indonesia');
    $objDrawing->setDescription('Logo Media Kreatif');
    $objDrawing->setPath('./assets/dist/img/hai.jpg');
    $objDrawing->setHeight(95);
    $objDrawing->setCoordinates('A1'); 
    $objDrawing->setWorksheet($excel->getActiveSheet());
    
    $excel->getDefaultStyle()->applyFromArray($styleArray);
    $excel->setActiveSheetIndex(0)->setCellValue('I1', "PT. HAMAKO APPAREL INDONESIA"); // Set kolom A1 dengan tulisan "DATA SISWA"
    $excel->setActiveSheetIndex(0)->setCellValue('I3', "www.hamakobaby. com"); // Set kolom A1 dengan tulisan "DATA SISWA"
    $excel->setActiveSheetIndex(0)->setCellValue('I4', "www.babybudshop. com"); // Set kolom A1 dengan tulisan "DATA SISWA"
    $excel->setActiveSheetIndex(0)->setCellValue('I5', "+62811 242 625 6"); // Set kolom A1 dengan tulisan "DATA SISWA"
    $excel->setActiveSheetIndex(0)->setCellValue('I8', "DEBIT NOTE"); // Set kolom A1 dengan tulisan "DATA SISWA"
    $excel->setActiveSheetIndex(0)->setCellValue('I10', "DEBIT NOTE NUMBER"); // Set kolom A1 dengan tulisan "DATA SISWA"
    $excel->setActiveSheetIndex(0)->setCellValue('A10', "RECIPIENT"); // Set kolom A1 dengan tulisan "DATA SISWA"
    // $excel->getActiveSheet()->mergeCells('A1:E1'); // Set Merge Cell pada kolom A1 sampai E1
    $excel->getActiveSheet()->getStyle('I1')->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->getActiveSheet()->getStyle('I1')->getFont()->setSize(12); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('I8')->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->getActiveSheet()->getStyle('I8')->getFont()->setSize(18); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('I10')->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->getActiveSheet()->getStyle('I10')->getFont()->setSize(12); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('A10')->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->getActiveSheet()->getStyle('A10')->getFont()->setSize(12); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('I3:I5')->getFont()->setColor( $phpColor );
    $excel->getActiveSheet()->getStyle('I1:I11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT); // Set text center untuk kolom A1
    
    // Buat header tabel nya pada baris ke 3
    $excel->setActiveSheetIndex(0)->setCellValue('A17', "DN DATE"); // Set kolom A3 dengan tulisan "NO"
    $excel->setActiveSheetIndex(0)->setCellValue('C17', "ITEM"); // Set kolom B3 dengan tulisan "NIS"
    $excel->setActiveSheetIndex(0)->setCellValue('E17', "QTY"); // Set kolom C3 dengan tulisan "NAMA"
    $excel->setActiveSheetIndex(0)->setCellValue('G17', "PRICE"); // Set kolom D3 dengan tulisan "JENIS KELAMIN"
    $excel->setActiveSheetIndex(0)->setCellValue('I17', "AMOUNT"); // Set kolom E3 dengan tulisan "ALAMAT"
    // Apply style header yang telah kita buat tadi ke masing-masing kolom header
    $excel->getActiveSheet()->getStyle('A17')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('C17')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('E17')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('G17')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('I17')->applyFromArray($style_col);
    
    // Panggil function view yang ada di SiswaModel untuk menampilkan semua data siswanya
    $sales  = $this->M_sales->get_sales($id_sale)->result();
    $detail = $this->M_sales->get_sales_detail($id_sale)->result();
    $sumqty = $this->M_sales->get_sum_sales($id_sale)->result();

    foreach($sales as $data){ }
    $excel->setActiveSheetIndex(0)->setCellValue('I11', $data->invoice);
    $excel->setActiveSheetIndex(0)->setCellValue('A12', $data->customername);
    $excel->setActiveSheetIndex(0)->setCellValue('A13', $data->alamat);
    $excel->setActiveSheetIndex(0)->setCellValue('A14', $data->tlp);

    $excel->getActiveSheet()->getStyle('I11')->getFont()->setColor( $phpColor );
    $excel->getActiveSheet()->getStyle('A12:A14')->getFont()->setColor( $phpColor );

    $excel->setActiveSheetIndex(0)->setCellValue('A19', $data->date);
    $excel->setActiveSheetIndex(0)->setCellValue('C19', "HAMAKO/AW19");
    
    $excel->getActiveSheet()->getStyle('C19')->getFont()->setSize(11); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('C19')->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->getActiveSheet()->getStyle('A19:C19')->getFont()->setColor( $phpColor );


    $no = 1; // Untuk penomoran tabel, di awal set dengan 1
    $numrow = 21; // Set baris pertama untuk isi tabel adalah baris ke 4
    $totalqty = 0;
    foreach($detail as $data){ // Lakukan looping pada variabel siswa
      $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->name);
      $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->qty);
      $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->price);
      $excel->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $data->total);
      // $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow++, " ");
      
        // Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
        // $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
        // $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
        // $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
        // $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
        // $excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('C'.$numrow.':I'.$numrow)->getFont()->setColor( $phpColor );
        $excel->getActiveSheet()->getStyle('G'.$numrow)->getNumberFormat()->setFormatCode('#,##');
        $excel->getActiveSheet()->getStyle('I'.$numrow)->getNumberFormat()->setFormatCode('#,##');
        $excel->getActiveSheet()->getStyle('E'.$numrow)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $excel->getActiveSheet()->getStyle('G'.$numrow)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
      
      $no++; // Tambah 1 setiap kali looping
      $numrow++; // Tambah 1 setiap kali looping
      
      $totalqty=  $totalqty + $data->qty;
    }
    $baristo = $numrow+2;
    $excel->setActiveSheetIndex(0)->setCellValue('E'.$baristo, $totalqty);
    $excel->getActiveSheet()->getStyle('E'.$baristo)->getFont()->setColor( $phpColor );
    $excel->getActiveSheet()->getStyle('E'.$baristo)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $baris = $numrow+4;
    $b1 = $baris + 2;
    $b2 = $baris + 4;
    $b3 = $baris + 7;
    $excel->getActiveSheet()->getStyle('G'.$baris)->getFont()->setBold(TRUE);
    $excel->getActiveSheet()->getStyle('G'.$b1)->getFont()->setBold(TRUE);
    $excel->getActiveSheet()->getStyle('G'.$b2)->getFont()->setBold(TRUE);
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$baris, "Subtotal");
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$b1, "Other");
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$b2, "TOTAL");
    $excel->getActiveSheet()->getStyle('G'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $excel->getActiveSheet()->getStyle('G'.$b1)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    $excel->getActiveSheet()->getStyle('G'.$b2)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    foreach($sales as $data){
    }
    
    $excel->setActiveSheetIndex(0)->setCellValue('I'.$baris, $data->total_price);
    $excel->setActiveSheetIndex(0)->setCellValue('I'.$b1, $data->discount);
    
    $excel->setActiveSheetIndex(0)->setCellValue('I'.$b2, $data->final_price);
    $excel->getActiveSheet()->getStyle('I'.$baris)->getNumberFormat()->setFormatCode('#,##');
    $excel->getActiveSheet()->getStyle('I'.$b1)->getNumberFormat()->setFormatCode('#,##');
    $excel->getActiveSheet()->getStyle('I'.$b2)->getNumberFormat()->setFormatCode('#,##');
    
    $excel->getActiveSheet()->getStyle('I'.$baris.':I'.$b2)->getFont()->setColor( $phpColor );    
    // $excel->setActiveSheetIndex(0)->setCellValue('G'.$barisqty, $data->jmlqty);
    
    // $sum = SUM($data->qty);
    // Set width kolom
    // Set Footer
    $b4 = $b3+1;
    $b5 = $b3+2;
    $b6 = $b3+4;
    $b7 = $b3+5;
    $b8 = $b3+6;
    $b9 = $b3+7;
    $b10 = $b3+8;
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b3, "PAY TO");
    $excel->getActiveSheet()->getStyle('A'.$b3)->getFont()->setSize(11); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('A'.$b3)->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b4, "MARIA MONICA");
    $excel->getActiveSheet()->getStyle('A'.$b4)->getFont()->setSize(11); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('A'.$b4)->getFont()->setColor( $phpColor );   
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b5, "BCA/3423307460");
    $excel->getActiveSheet()->getStyle('A'.$b5)->getFont()->setSize(11); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('A'.$b5)->getFont()->setColor( $phpColor );  
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b6, "NOTES");
    $excel->getActiveSheet()->getStyle('A'.$b6)->getFont()->setSize(11); // Set font size 15 untuk kolom A1
    $excel->getActiveSheet()->getStyle('A'.$b6)->getFont()->setBold(TRUE); // Set bold kolom A1
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b7, "Payment should be paid in full no later than 14 calendar days after receiving this debit note.");
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b8, "Have a nice day and Thank you!");
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b9, "Love, Hamako");
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$b10, "Hamako Apparel Indonesia @2018  | hamako.ecobabwear@gmail.com");
    $excel->getActiveSheet()->getStyle('A'.$b7.':A'.$b10)->getFont()->setColor( $phpColor );  

    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(12); // Set width kolom A
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(6); // Set width kolom B
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(34); // Set width kolom C
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(6); // Set width kolom D
    $excel->getActiveSheet()->getColumnDimension('E')->setWidth(9); // Set width kolom E
    $excel->getActiveSheet()->getColumnDimension('F')->setWidth(6); // Set width kolom F
    $excel->getActiveSheet()->getColumnDimension('G')->setWidth(12); // Set width kolom G
    $excel->getActiveSheet()->getColumnDimension('H')->setWidth(6); // Set width kolom H
    $excel->getActiveSheet()->getColumnDimension('I')->setWidth(16); // Set width kolom I
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    // Set judul file excel nya
    $excel->getActiveSheet(0)->setTitle("Debit Note");
    $excel->setActiveSheetIndex(0);
    // Proses file excel
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    $date = date("dmyhis");
    header('Content-Disposition: attachment; filename="HAI-Debit Note"'.$date.'".xlsx"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');
    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }

  
  // Filter By Tanggal dan produk

  public function export_sales($id_sale = null){
      // Load plugin PHPExcel nya
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    
    // Panggil class PHPExcel nya
    $excel = new PHPExcel();
    // Settingan awal fil excel
    $excel->getProperties()->setCreator('My Notes Code')
                 ->setLastModifiedBy('My Notes Code')
                 ->setTitle("Debit Note")
                 ->setSubject("Debit Note")
                 ->setDescription("Laporan Debit Note")
                 ->setKeywords("Debit Note");
    // Buat sebuah variabel untuk menampung pengaturan style dari header tabel

    $styleArray = array(
      'font'  => array(
           'name'  => 'Arial'
       ));      
    $phpColor = new PHPExcel_Style_Color();
    $phpColor->setRGB('757171');

    $style_col = array(
      'font' => array('bold' => true), // Set font nya jadi bold
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );

    // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
    $style_row = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
      )
    );
    // Menambahkan file gambar pada document excel pada kolom B2
    $objDrawing = new PHPExcel_Worksheet_Drawing();
    $objDrawing->setName('Media Kreatif Indonesia');
    $objDrawing->setDescription('Logo Media Kreatif');
    $objDrawing->setPath('./assets/dist/img/hai.jpg');
    $objDrawing->setHeight(70);
    $objDrawing->setCoordinates('A1'); 
    $objDrawing->setWorksheet($excel->getActiveSheet());
    
    $excel->getDefaultStyle()->applyFromArray($styleArray);
    $excel->setActiveSheetIndex(0)->setCellValue('A1', "LAPORAN PENJUALAN HAI");
    $excel->getActiveSheet()->mergeCells('A1:H2'); 
    $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);
    $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);
    $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // Set text center untuk kolom A1
    
    // Buat header tabel nya pada baris ke 3
    $excel->setActiveSheetIndex(0)->setCellValue('A5', "NO");
    $excel->setActiveSheetIndex(0)->setCellValue('B5', "DATE ORDER");
    $excel->setActiveSheetIndex(0)->setCellValue('C5', "BARCODE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('D5', "PRODUCT"); 
    $excel->setActiveSheetIndex(0)->setCellValue('E5', "QTY"); 
    $excel->setActiveSheetIndex(0)->setCellValue('F5', "DISCOUNT ITEM"); 
    $excel->setActiveSheetIndex(0)->setCellValue('G5', "PRICE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('H5', "TOTAL"); 
    
    // Apply style header yang telah kita buat tadi ke masing-masing kolom header
    $excel->getActiveSheet()->getStyle('A5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('B5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('C5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('D5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('E5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('F5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('G5')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('H5')->applyFromArray($style_col);
    
    $sales  = $this->M_sales->get_sales_bydate()->result();
    $discount  = $this->M_sales->get_sum()->result();
    $final  = $this->M_sales->get_sum_final()->result();
    $no = 1; // Untuk penomoran tabel, di awal set dengan 1
    $numrow = 6; // Set baris pertama untuk isi tabel adalah baris ke 4
    $totalqty = 0;
    foreach($sales as $data){ // Lakukan looping pada variabel siswa
      $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
      $excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->date);
      $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->barcode);
      $excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->name);
      $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->qty);
      $excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $data->discount_item);      
      $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->price);
      $excel->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $data->total);
          
      // Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
      $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);      
      $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('F'.$numrow)->getNumberFormat()->setFormatCode('#,##');
      $excel->getActiveSheet()->getStyle('G'.$numrow)->getNumberFormat()->setFormatCode('#,##');
      $excel->getActiveSheet()->getStyle('H'.$numrow)->getNumberFormat()->setFormatCode('#,##');
        
      
      $no++; // Tambah 1 setiap kali looping
      $numrow++; // Tambah 1 setiap kali looping
      
      $totalqty=  $totalqty + $data->qty;
    }
    $baristo = $numrow+1;
    $excel->setActiveSheetIndex(0)->setCellValue('E'.$baristo, $totalqty);
    $excel->getActiveSheet()->getStyle('E'.$baristo)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
    foreach($discount as $data){
      $excel->setActiveSheetIndex(0)->setCellValue('F'.$baristo, $data->discount_item);
      $excel->setActiveSheetIndex(0)->setCellValue('H'.$baristo, $data->total);
      
      $excel->getActiveSheet()->getStyle('F'.$baristo)->getNumberFormat()->setFormatCode('#,##');
      $excel->getActiveSheet()->getStyle('H'.$baristo)->getNumberFormat()->setFormatCode('#,##');
    }
    $baris = $numrow+1;
    $b1 = $numrow+2;
    $b2 = $numrow+3;
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$baris, "Subtotal");
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$b1, "Discount");
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$b2, "TOTAL");
    $excel->getActiveSheet()->getStyle('G'.$baris)->getFont()->setBold(TRUE);
    $excel->getActiveSheet()->getStyle('G'.$b1)->getFont()->setBold(TRUE);
    $excel->getActiveSheet()->getStyle('G'.$b2)->getFont()->setBold(TRUE);
    $excel->getActiveSheet()->getStyle('G'.$baris)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
    $excel->getActiveSheet()->getStyle('G'.$b1)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
    $excel->getActiveSheet()->getStyle('G'.$b2)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
    
    foreach($final as $data){
      $excel->setActiveSheetIndex(0)->setCellValue('H'.$b1, $data->discount);
      $excel->setActiveSheetIndex(0)->setCellValue('H'.$b2, $data->final);
      
      $excel->getActiveSheet()->getStyle('H'.$b1)->getNumberFormat()->setFormatCode('#,##');
      $excel->getActiveSheet()->getStyle('H'.$b2)->getNumberFormat()->setFormatCode('#,##');
    }


    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(6); // Set width kolom A
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(12); // Set width kolom B
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(12); // Set width kolom C
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(30); // Set width kolom D
    $excel->getActiveSheet()->getColumnDimension('E')->setWidth(5); // Set width kolom E
    $excel->getActiveSheet()->getColumnDimension('F')->setWidth(16); // Set width kolom F
    $excel->getActiveSheet()->getColumnDimension('G')->setWidth(12); // Set width kolom G
    $excel->getActiveSheet()->getColumnDimension('H')->setWidth(12); // Set width kolom H
    
    // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
    // Set orientasi kertas jadi LANDSCAPE
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
    // Set judul file excel nya
    $excel->getActiveSheet(0)->setTitle("Laporan Penjualan");
    $excel->setActiveSheetIndex(0);
    // Proses file excel
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    $date = date("dmyhis");
    header('Content-Disposition: attachment; filename="Laporan Penjualan"'.$date.'".xlsx"'); // Set nama file excel nya
    header('Cache-Control: max-age=0');
    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }
  
  public function export_item(){
    // Load plugin PHPExcel nya
  include APPPATH.'third_party/PHPExcel/PHPExcel.php';
  
  // Panggil class PHPExcel nya
  $excel = new PHPExcel();
  // Settingan awal fil excel
  $excel->getProperties()->setCreator('My Notes Code')
               ->setLastModifiedBy('My Notes Code')
               ->setTitle("Debit Note")
               ->setSubject("Debit Note")
               ->setDescription("Laporan Debit Note")
               ->setKeywords("Debit Note");
  // Buat sebuah variabel untuk menampung pengaturan style dari header tabel

  $styleArray = array(
    'font'  => array(
         'name'  => 'Arial'
     ));      
  $phpColor = new PHPExcel_Style_Color();
  $phpColor->setRGB('757171');

  $style_col = array(
    'font' => array('bold' => true), // Set font nya jadi bold
    'alignment' => array(
      'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
      'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
    ),
    'borders' => array(
      'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
      'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
      'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
      'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
    )
  );

  // Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
  $style_row = array(
    'alignment' => array(
      'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
    ),
    'borders' => array(
      'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
      'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
      'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
      'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
    )
  );
  // Menambahkan file gambar pada document excel pada kolom B2
  $objDrawing = new PHPExcel_Worksheet_Drawing();
  $objDrawing->setName('Media Kreatif Indonesia');
  $objDrawing->setDescription('Logo Media Kreatif');
  $objDrawing->setPath('./assets/dist/img/hai.jpg');
  $objDrawing->setHeight(70);
  $objDrawing->setCoordinates('A1'); 
  $objDrawing->setWorksheet($excel->getActiveSheet());
  
  $excel->getDefaultStyle()->applyFromArray($styleArray);
  $excel->setActiveSheetIndex(0)->setCellValue('A1', "LAPORAN STOK HAI");
  $excel->getActiveSheet()->mergeCells('A1:I2'); 
  $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);
  $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(12);
  $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // Set text center untuk kolom A1
  
  // Buat header tabel nya pada baris ke 3
  $excel->setActiveSheetIndex(0)->setCellValue('A5', "NO");
  $excel->setActiveSheetIndex(0)->setCellValue('B5', "BARCODE");
  $excel->setActiveSheetIndex(0)->setCellValue('C5', "NAMA"); 
  $excel->setActiveSheetIndex(0)->setCellValue('D5', "JENIS"); 
  $excel->setActiveSheetIndex(0)->setCellValue('E5', "MERK"); 
  $excel->setActiveSheetIndex(0)->setCellValue('F5', "HPP"); 
  $excel->setActiveSheetIndex(0)->setCellValue('G5', "FOB"); 
  $excel->setActiveSheetIndex(0)->setCellValue('H5', "KOLEKSI"); 
  $excel->setActiveSheetIndex(0)->setCellValue('I5', "STOK"); 
  
  // Apply style header yang telah kita buat tadi ke masing-masing kolom header
  $excel->getActiveSheet()->getStyle('A5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('B5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('C5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('D5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('E5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('F5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('G5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('H5')->applyFromArray($style_col);
  $excel->getActiveSheet()->getStyle('I5')->applyFromArray($style_col);
  
  $item  = $this->M_item->get()->result();
  
  $no = 1; // Untuk penomoran tabel, di awal set dengan 1
  $numrow = 6; // Set baris pertama untuk isi tabel adalah baris ke 4

  foreach($item as $data){ // Lakukan looping pada variabel siswa
    $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
    $excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->barcode);
    $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->name);
    $excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->name_jenis);
    $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->name_merk);
    $excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $data->hpp);      
    $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->fob);
    $excel->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $data->name_koleksi);
    $excel->setActiveSheetIndex(0)->setCellValue('I'.$numrow, $data->stock);
        
    // Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
    $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);      
    $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style_row);
    $excel->getActiveSheet()->getStyle('F'.$numrow)->getNumberFormat()->setFormatCode('#,##');
    $excel->getActiveSheet()->getStyle('G'.$numrow)->getNumberFormat()->setFormatCode('#,##');
      
    
    $no++; // Tambah 1 setiap kali looping
    $numrow++; // Tambah 1 setiap kali looping
    
  }
  

  $excel->getActiveSheet()->getColumnDimension('A')->setWidth(6); // Set width kolom A
  $excel->getActiveSheet()->getColumnDimension('B')->setWidth(12); // Set width kolom B
  $excel->getActiveSheet()->getColumnDimension('C')->setWidth(30); // Set width kolom C
  $excel->getActiveSheet()->getColumnDimension('D')->setWidth(12); // Set width kolom D
  $excel->getActiveSheet()->getColumnDimension('E')->setWidth(12); // Set width kolom E
  $excel->getActiveSheet()->getColumnDimension('F')->setWidth(12); // Set width kolom F
  $excel->getActiveSheet()->getColumnDimension('G')->setWidth(12); // Set width kolom G
  $excel->getActiveSheet()->getColumnDimension('H')->setWidth(12); // Set width kolom H
  $excel->getActiveSheet()->getColumnDimension('I')->setWidth(12); // Set width kolom H
  
  // Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
  $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
  // Set orientasi kertas jadi LANDSCAPE
  $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
  // Set judul file excel nya
  $excel->getActiveSheet(0)->setTitle("Laporan Penjualan");
  $excel->setActiveSheetIndex(0);
  // Proses file excel
  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  $date = date("dmyhis");
  header('Content-Disposition: attachment; filename="Laporan Stok"'.$date.'".xlsx"'); // Set nama file excel nya
  header('Cache-Control: max-age=0');
  $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
  $write->save('php://output');
}



}
