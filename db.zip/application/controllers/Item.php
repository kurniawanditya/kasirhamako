<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item extends CI_Controller {
  function __construct(){
    parent::__construct();
    check_not_login();
    $this->load->library('datatables');
    $this->load->model(['M_item','M_jenis','M_merk','M_koleksi']);
  }

  public function json()
  {
    header('Content-Type: application/json');
    echo $this->M_item->get_all_item();
  }


  public function index()
  { 
    $data = array(
    'jenis'   => $this->M_jenis->get(),
    'row'     => $this->M_item->get(),
    'merk'    => $this->M_merk->get(),
    'koleksi' => $this->M_koleksi->get(),
    );
    $this->template->load('template','products/item/item_data',$data);
  }


  public function add(){
    $item = new stdClass();
    $item->id_item = null;
    $item->name= null;
    $item->barcode= null;
    $item->hpp= null;
    $item->fob= null;

    $query_jenis = $this->M_jenis->get();
    $jenis[null] ='-pilih-';
    foreach ($query_jenis->result() as $jns) {
      $jenis[$jns->id_jenis] = $jns->name_jenis;
    }

    $query_merk = $this->M_merk->get();
    $merk[null] ='-pilih-';
    foreach ($query_merk->result() as $mrk) {
      $merk[$mrk->id_merk] = $mrk->name_merk;
    }

    $query_koleksi = $this->M_koleksi->get();
    $koleksi[null] ='-pilih-';
    foreach ($query_koleksi->result() as $klk) {
      $koleksi[$klk->id_koleksi] = $klk->name_koleksi;
    }


    $data = array(
      'page'  => 'add',
      'row'   => $item,
      'jenis' =>$jenis,'selectedjenis'=>null,
      'merk'  =>$merk,'selectedmerk'=>null,
      'koleksi'=>$koleksi,'selectedkoleksi'=>null);
    $this->template->load('template','products/item/item_form',$data);
  }

  // public function update($id){
  //   $query = $this->M_item->get($id);

  //   if($query->num_rows()> 0){
  //     $item = $query->row();
  //     $query_jenis = $this->M_jenis->get();
  //     $jenis[null] ='-pilih-';
  //     foreach ($query_jenis->result() as $jns) {
  //       $jenis[$jns->id_jenis] = $jns->name_jenis;
  //     }

  //     $query_merk = $this->M_merk->get();
  //     $merk[null] ='-pilih-';
  //     foreach ($query_merk->result() as $mrk) {
  //       $merk[$mrk->id_merk] = $mrk->name_merk;
  //     }

  //     $query_koleksi = $this->M_koleksi->get();
  //     $koleksi[null] ='-pilih-';
  //     foreach ($query_koleksi->result() as $klk) {
  //       $koleksi[$klk->id_koleksi] = $klk->name_koleksi;
  //     }

  //       $data = array(
  //       'page'    => 'update',
  //       'row'     => $item,
  //       'jenis'   => $jenis,'selectedjenis'=>$item->id_jenis,
  //       'merk'    => $merk,'selectedmerk'=>$item->id_merk,
  //       'koleksi' =>$koleksi,'selectedkoleksi'=>$item->id_koleksi);
  //     $this->template->load('template','products/item/item_form',$data);
  //   }else{
  //     echo "<script>alert('Data Tidak Ditemukan');";
  //     redirect('item');

  //   }

  // }

  function update(){ //function update data
    $kode=$this->input->post('kode');
    $data=array(
      'name'     => $this->input->post('name'),
      'jenis'    => $this->input->post('jenis'),
      'merk' => $this->input->post('merk'),
      'hpp' => $this->input->post('hpp'),
      'fob' => $this->input->post('fob'),
      'koleksi' => $this->input->post('koleksi'),
      'stock' => $this->input->post('stock')
    );
    $this->db->where('id_item',$kode);
    $this->db->update('t_item', $data);
    echo "<script>alert('Data Berhasil di Update');";
        redirect('item');
  }

  public function process(){
    $post = $this->input->post(null, TRUE);
    if(isset($post['add'])){
      $this->M_item->add($post);
    }else if(isset($post['update'])){
      $this->M_item->update($post);
    }
    if($this->db->affected_rows()>0){
      $this->session->set_flashdata('success', 'Data Berhasil Disimpan');
    }
    redirect('item');
  }


  public function delete($id)
  {
    $this->M_item->delete($id);
    if($this->db->affected_rows()>0){
      $this->session->set_flashdata('success', 'Data Berhasil Dihapus');
    }
    redirect('item');

  }

  public function import()
  {
    $this->template->load('template','products/item/item_form_import');
  }
  public function prosesimport()
  {
    // Load plugin PHPExcel nya
        include APPPATH.'third_party/PHPExcel/PHPExcel.php';

        $config['upload_path'] = realpath('excel');
        $config['allowed_types'] = 'xlsx|xls|csv';
        $config['max_size'] = '10000';
        $config['encrypt_name'] = true;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload()) {

            //upload gagal
            $this->session->set_flashdata('notif', '<div class="alert alert-danger"><b>PROSES IMPORT GAGAL!</b> '.$this->upload->display_errors().'</div>');
            //redirect halaman
            redirect('item');

        } else {

            $data_upload = $this->upload->data();

            $excelreader     = new PHPExcel_Reader_Excel2007();
            $loadexcel         = $excelreader->load('excel/'.$data_upload['file_name']); // Load file yang telah diupload ke folder excel
            $sheet             = $loadexcel->getActiveSheet()->toArray(null, true, true ,true);

            $data = array();

            $numrow = 1;
            foreach($sheet as $row){
                            if($numrow > 1){
                                array_push($data, array(
                                    'id_item' => $row['A'],
                                    'barcode' => $row['B'],
                                    'name'    => $row['C'],
                                    'jenis'   => $row['D'],
                                    'merk'    => $row['E'],
                                    'hpp'     => $row['F'],
                                    'fob'     => $row['G'],
                                    'koleksi' => $row['H'],
                                    'stock'   => $row['I'],
                                ));
                    }
                $numrow++;
            }
            $this->db->insert_batch('t_item', $data);
            //delete file from server
            unlink(realpath('excel/'.$data_upload['file_name']));

            //upload success
            $this->session->set_flashdata('notif', '<div class="alert alert-success"><b>PROSES IMPORT BERHASIL!</b> Data berhasil diimport!</div>');
            //redirect halaman
            redirect('item');

        }
    }

}
