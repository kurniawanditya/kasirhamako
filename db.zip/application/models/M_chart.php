<?php
class M_chart extends CI_Model{
 
  //get data from database
  function get_data(){
      $this->db->select('c.name_jenis, SUM(a.qty) as total');
      $this->db->join('t_item b','b.id_item=a.id_item');
      $this->db->join('t_jenis c','b.jenis=c.id_jenis');
      $this->db->group_by('a.id_item');
      $result = $this->db->get('t_sales_detail a');
      return $result;
  }
 
}